.. SPDX-License-Identifier: BSD-2-Clause
   Copyright 2013-2024, John McNamara, jmcnamara@cpan.org

.. _ex_hyperlink:

Example: Adding hyperlinks
==========================

This program is an example of writing hyperlinks to a worksheet. See the
:func:`write_url` method for more details.

.. image:: _images/hyperlink.png

.. literalinclude:: ../../../examples/hyperlink.py

