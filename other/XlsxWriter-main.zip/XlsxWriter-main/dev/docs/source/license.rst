.. SPDX-License-Identifier: BSD-2-Clause
   Copyright 2013-2024, John McNamara, jmcnamara@cpan.org

.. _license:

License
=======

XlsxWriter is released under a BSD 2-Clause license.


.. include:: ../../../LICENSE.txt
