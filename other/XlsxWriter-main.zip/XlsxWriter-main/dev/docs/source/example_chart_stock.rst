.. SPDX-License-Identifier: BSD-2-Clause
   Copyright 2013-2024, John McNamara, jmcnamara@cpan.org

.. _ex_chart_stock:

Example: Stock Chart
====================

Example of creating and Excel HiLow-Close Stock chart.

Chart 1 in the following example is:

.. image:: _images/chart_stock1.png
   :scale: 75 %

.. literalinclude:: ../../../examples/chart_stock.py
