.. SPDX-License-Identifier: BSD-2-Clause
   Copyright 2013-2024, John McNamara, jmcnamara@cpan.org

.. _ex_chartsheet:

Example: Chartsheet
===================

Example of creating an Excel Bar chart on a :ref:`chartsheet <Chartsheet>`.

.. image:: _images/chartsheet.png

.. literalinclude:: ../../../examples/chartsheet.py
