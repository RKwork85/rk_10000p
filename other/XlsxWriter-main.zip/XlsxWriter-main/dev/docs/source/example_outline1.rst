.. SPDX-License-Identifier: BSD-2-Clause
   Copyright 2013-2024, John McNamara, jmcnamara@cpan.org

.. _ex_outline1:

Example: Outline and Grouping
=============================

Examples of how use XlsxWriter to generate Excel outlines and grouping. See
also :ref:`outlines`.

.. image:: _images/outline1.png

.. literalinclude:: ../../../examples/outline.py
