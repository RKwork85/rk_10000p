.. SPDX-License-Identifier: BSD-2-Clause
   Copyright 2013-2024, John McNamara, jmcnamara@cpan.org

.. _ex_django_simple:

Example: Simple Django class
============================

A simple Django View class to write an Excel file using the XlsxWriter module.

.. literalinclude:: ../../../examples/django_simple.py
