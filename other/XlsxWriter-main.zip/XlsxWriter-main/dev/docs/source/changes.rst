.. SPDX-License-Identifier: BSD-2-Clause
   Copyright 2013-2024, John McNamara, jmcnamara@cpan.org

:tocdepth: 1

.. _changes:

Changes in XlsxWriter
=====================

This section shows changes and bug fixes in the XlsxWriter module.

.. include:: ../../../Changes
