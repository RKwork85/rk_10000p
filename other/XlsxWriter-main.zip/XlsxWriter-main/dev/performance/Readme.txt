
This directory contains some simple tests programs for testing
performance of the XlsxWriter module.

See the perf_test.sh shell script for examples.

perf_pyx.py: The initial performance and memory test for XlsxWriter. This is
             no longer valid for OpenPyXL.

perf2.py: A newer benchmark that take formats and some other features into
          account.

perf3.py: A better performance comparison between XlsxWriter and OpenPyXL.
